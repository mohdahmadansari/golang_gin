## Run this command to start golang server

go run main.go


## Open this URL to get Swagger

http://localhost:5000/swagger/index.html#/

![Screenshot](screenshot.png)
